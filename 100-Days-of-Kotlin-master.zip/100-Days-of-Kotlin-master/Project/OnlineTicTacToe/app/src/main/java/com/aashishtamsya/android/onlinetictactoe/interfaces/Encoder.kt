package com.aashishtamsya.android.onlinetictactoe.interfaces

interface Encoder {
    fun encode(): HashMap<String, Any>
}